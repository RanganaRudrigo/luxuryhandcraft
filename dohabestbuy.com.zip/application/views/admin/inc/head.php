
<title><?= PROJECT_TITLE ?></title>
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">

    <link rel="shortcut icon" href="<?= base_url() ?>assets/img/favicon.png" />

    <!-- bootstrap framework -->
    <link href="<?= base_url() ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">

    <!-- custom icons -->
    <!-- font awesome icons -->
    <link href="<?= base_url() ?>assets/icons/font-awesome/css/font-awesome.min.css" rel="stylesheet" media="screen">
    <!-- ionicons -->
    <link href="<?= base_url() ?>assets/icons/ionicons/css/ionicons.min.css" rel="stylesheet" media="screen">

    <!-- main stylesheet -->
    <link href="<?= base_url() ?>assets/css/style.css" rel="stylesheet" media="screen">

    <!-- google webfonts -->
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400&amp;subset=latin-ext,latin' rel='stylesheet' type='text/css'>

    <!-- moment.js (date library) -->
    <script src="<?= base_url() ?>assets/lib/moment-js/moment.min.js"></script>

    <script type="text/javascript" >
        URL = {  base : "<?=base_url()?>admin/" , current : "<?=current_url()?>" }
    </script>
