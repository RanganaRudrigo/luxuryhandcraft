<!-- jQuery -->
<script src="<?= base_url() ?>assets/js/jquery.min.js"></script>
<!-- easing -->
<script src="<?= base_url() ?>assets/js/jquery.easing.1.3.min.js"></script>
<!-- bootstrap js plugins -->
<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
<!-- top dropdown navigation -->
<script src="<?= base_url() ?>assets/js/tinynav.js"></script>
<!-- perfect scrollbar -->
<script src="<?= base_url() ?>assets/lib/perfect-scrollbar/min/perfect-scrollbar-0.4.8.with-mousewheel.min.js"></script>

<!-- common functions -->
<script src="<?= base_url() ?>assets/js/tisa_common.js"></script>

<!-- Modal -->
<div class="modal fade" id="myModal"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        </div>
    </div>
</div>