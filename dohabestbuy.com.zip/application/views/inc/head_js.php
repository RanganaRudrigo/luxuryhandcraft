<script>
    var isLogged = <?= $this->session->has_userdata("front_user") ? 1 : 0 ?>;
    var mywishlist_url = '<?= base_url() ?>user/wishlist';
    var baseDir = '<?= base_url() ?>';
    var baseUri = '<?= base_url() ?>';
</script>
<script type="text/javascript" src="<?=base_url()?>js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.easing.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/tools.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/global.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/10-bootstrap.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/15-jquery.total-storage.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/15-jquery.uniform-modified.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.fancybox.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/products-comparison.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/ajax-cart.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.scrollTo.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.serialScroll.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.bxslider.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/treeManagement.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/blocknewsletter.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/blocksearch.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/homeslider.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/ajax-wishlist.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/waypoints.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/instafeed.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.stellar.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/owl.carousel.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/countdown.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/script.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/raphael-min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/iview.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.autocomplete_productsearch.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/leosearch.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery.cooki-plugin.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/colorpicker.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/paneltool.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/index.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/profile1442473272.js"></script>