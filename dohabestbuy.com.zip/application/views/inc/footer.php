<footer id="footer" class="footer-container">
  <div class="container">
    <!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
    <div        class="row no-margin footer-top ApRow has-bg bg-boxed"
                data-bg=" #5d4e57 no-repeat"                style="background: #5d4e57 no-repeat;padding-top: 30px;padding-bottom: 18px;"        >

      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="footer-topleft col-lg-6 col-md-6 col-sm-12 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->

        <!-- Block Newsletter module-->
        <div id="newsletter_block_left" class="block inline">
          <h4 class="title_block">Subscribe</h4>
          <div class="block_content">
            <form action="" method="post">
              <div class="form-group" >
                <input class="inputNew form-control grey newsletter-input" id="newsletter-input" type="text" name="email" size="18" value="Enter your e-mail" />
                <button type="submit" name="submitNewsletter" class="btn button button-small"> <i class="fa fa-arrow-right"></i> </button>
                <input type="hidden" name="action" value="0" />
              </div>
            </form>
          </div>
        </div>
        <!-- /Block Newsletter module-->

      </div>
      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="footer-topright col-lg-6 col-md-6 col-sm-12 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->

        <div id="social_block">
          <h4 class="title_block">stay connect</h4>
          <ul>
            <li class="facebook"> <a class="_blank" href=""> <span>Facebook</span> </a> </li>
            <li class="twitter"> <a class="_blank" href=""> <span>Twitter</span> </a> </li>
            <li class="rss"> <a class="_blank" href=""> <span>RSS</span> </a> </li>
            <li class="google-plus"> <a class="_blank" href="" rel="publisher"> <span>Google Plus</span> </a> </li>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
    <div id="form_4041031043959163"        class="row footer-center ApRow has-bg bg-fullwidth"
         data-bg=" #FFF no-repeat"                style="padding-top: 70px;padding-bottom: 0px;"        >

      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="col-lg-2 col-md-4 col-sm-4 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->

        <!-- Block CMS module footer -->
        <div class="footer-block block" id="block_various_links_footer">
          <h4 class="title_block">Information</h4>
          <ul class="toggle-footer list-group bullet">
            <li class="item"> <a href="" title="Best sellers"> Best sellers </a> </li>
            <li class="item"> <a href="" title="Our stores"> Our stores </a> </li>
            <li class="item"> <a href="" title="Contact us"> Contact us </a> </li>
            <li class="item"> <a href="" title="About us"> About us </a> </li>
            <li> <a href="" title="Sitemap"> Sitemap </a> </li>
          </ul>
        </div>
        <!-- /Block CMS module footer -->

      </div>
      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="col-lg-2 col-md-4 col-sm-4 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApBlockLink -->

        <div id="blockLink-form_9455992187716288" class="ApBlockLink">
          <div class="footer-block block">
            <h4 class="title_block">Extras</h4>
            <ul class="toggle-footer list-group bullet">
              <li><a href="#">Brands</a></li>
              <li><a href="#">Specials</a></li>
              <li><a href="#">New products</a></li>
              <li><a href="#">Our stores</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
        </div>
      </div>
      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="col-lg-2 col-md-4 col-sm-4 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->

        <!-- Block myaccount module -->
        <div class="footer-block block">
          <h4 class="title_block"><a href="" title="Manage my customer account" rel="nofollow">My account</a></h4>
          <div class="block_content toggle-footer">
            <ul class="bullet toggle-footer list-group">
              <li><a href="" title="My orders" rel="nofollow">My orders</a></li>
              <li><a href="" title="My credit slips" rel="nofollow">My credit slips</a></li>
              <li><a href="" title="My addresses" rel="nofollow">My addresses</a></li>
              <li><a href="" title="Manage my personal information" rel="nofollow">My personal info</a></li>
            </ul>
          </div>
        </div>
        <!-- /Block myaccount module -->

      </div>
      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="footer-html1 col-lg-3 col-md-6 col-sm-6 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApGeneral -->
        <div
            class="ApHtml block">
          <h4 class="title_block">Contact us</h4>
          <div class="block_content">
            <p>Duis sed odio sit amet nibh vulputate morbi accumsan ipsum velit. Nam nec tellus a odio mauris vitae erat consequat auctor eu in elit Class aptent taciti sociosqu litora torquent per inceptos himenaeos.</p>
          </div>
        </div>
      </div>
      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="footer-html2 col-lg-3 col-md-6 col-sm-6 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApGeneral -->
        <div
            class="ApHtml block">
          <div class="block_content">
            <address class="space-top-50">
              <span class="text-uppercase black">main office</span><br />
              PO Box 16122 Collins Street West Victoria 8007 Australia<br />
              844 123 456 78 / 844 123 456 79<br />
              <a href="mailto:#">contact@yourcompany.com</a>
            </address>
          </div>
        </div>
      </div>
    </div>
    <!-- @file modules\appagebuilder\views\templates\hook\ApRow -->

    <!-- @file modules\appagebuilder\views\templates\hook\ApRow -->

    <!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
    <div id="form_9610406899159048"        class="row ApRow has-bg bg-fullwidth"
         data-bg=" #FFF no-repeat"                style="padding-top: 35px;"        >

      <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
      <div    class="text-center col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12 ApColumn "
          >
        <!-- @file modules\appagebuilder\views\templates\hook\ApGeneral -->
        <div
            class="ApHtml block">
          <div class="block_content">
            <p class="copyright">Copyright � 2016 Doha Best Buy - All rights reserved. Powered by IT MARTX</p>
          </div>
        </div>
      </div>
    </div>
    <!-- @file modules\appagebuilder\views\templates\hook\header -->
    <script type='text/javascript'>
      var leoOption = {
        productNumber:1,
        productInfo:0,
        productTran:0,
        productCdown: 1,
        productColor: 0,
        homeWidth: 250,
        homeheight: 250,
      }

      $(document).ready(function(){
        var leoCustomAjax = new $.LeoCustomAjax();
        leoCustomAjax.processAjax();
      });
      // Javascript code
    </script>
  </div>
</footer>