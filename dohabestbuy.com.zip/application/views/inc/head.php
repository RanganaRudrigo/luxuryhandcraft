<meta charset="utf-8" />
<title>Doha Best Buy</title>
<meta name="description" content="" />
<meta name="generator" content="" />
<meta name="viewport" content="width=device-width, minimum-scale=0.25, maximum-scale=1.6, initial-scale=1.0" />
<link rel="shortcut icon" type="image/x-icon" href="" />
<link rel="stylesheet" href="<?= base_url() ?>css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:300,800,600&amp;subset=latin,latin-ext" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Lato:400,700,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>
<?php $d = array();  foreach($this->compare->contents() as $i ) $d[] = (int)$i['id'] ; ?>
<script>
    var comparedProductsIds = <?= json_encode($d) ?>;
</script>