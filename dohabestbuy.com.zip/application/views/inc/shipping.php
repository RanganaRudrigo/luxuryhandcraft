<form action="<?=base_url()?>cart/order?step=5" method="post" class="std form-horizontal" id="add_address">

    <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
            <div class="checkbox">
                <input type="checkbox" id="shipping_address" value="1">
                <label for="shipping_address"> Shipping Address Same as primary Address  </label>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-sm-4" for="other">Shipping Address </label>
        <div class="col-sm-6">
            <input type="hidden" name="id" value="<?= $cus->id ?>" >
            <textarea class="validate form-control" data-validate="isMessage" id="shipping" name="shipping" cols="26" rows="3"></textarea>
        </div>
    </div>
    <div class="clearfix"></div>
    <p class="submit2 text-center">

        <button type="submit"  id="submitAddress" class="btn btn-outline button button-medium">
				<span>
					Save
				</span>
        </button>
    </p>
</form>