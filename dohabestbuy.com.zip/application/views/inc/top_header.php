<div class="top-bar">
    <div class="container">
      <div class="row hidden-xs">
        <div class="col-sm-4 login-info">
          <ul class="account" id="tools">
            <li><a href="" id="" name="main:lnkSignIn"><span id="">Sign In</span></a> </li>
          </ul>
        </div>
        <div class="col-sm-8 free-shipping">
          <div><span class="sliderShipping1" id="main:lblSfFooterShipping1Index">FREE SHIPPING!&#160;</span> </div>
          <div class="free"><span class="sliderShipping2" id="">on orders $100+ // within the lower 48 states</span> </div>
        </div>
      </div>
      <div class="col-sm-8 free-shipping visible-xs">
        <div><span class="sliderShipping1" id="main:lblSfFooterShipping1IndexMobile">FREE SHIPPING!&#160;</span> </div>
        <div class="free"><span class="sliderShipping2" id="">on orders $100+ // within the lower 48 states</span> </div>
      </div>
    </div>
  </div>