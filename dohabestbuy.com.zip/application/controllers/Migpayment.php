<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 4/8/2016
 * Time: 9:45 AM
 */
class Migpayment extends CI_Controller
{



    private $name = '';
    protected $errors = array();

    protected function index() {

        $classname = str_replace('vq2-catalog_controller_payment_', '', basename(__FILE__, '.php'));
        $store_url = ($this->config->get('config_ssl') ? (is_numeric($this->config->get('config_ssl'))) ? str_replace('http', 'https', $this->config->get('config_url')) : $this->config->get('config_ssl') : $this->config->get('config_url'));
        $this->data['classname'] = $classname;
        $this->data['testmode'] = $this->config->get($classname . '_test');
        $this->data = array_merge($this->data, $this->load->language('payment/' . $classname));
        $this->data['error'] = (isset($this->session->data['error'])) ? $this->session->data['error'] : NULL;
        unset($this->session->data['error']);


        $this->data['fields'] = array();

        $this->data['hosting'] = $this->config->get($classname . '_hosting');

        if ($this->config->get($classname . '_hosting')) { //Server Hosted = 1, Merchant Hosted = 0

            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
            // v14x Backwards Compatibility
            if (isset($order_info['currency_code'])) { $order_info['currency'] = $order_info['currency_code']; }
            if (isset($order_info['currency_value'])) { $order_info['value'] = $order_info['currency_value']; }

            $currency = $order_info['currency'];

            // Loop through MID and currencies
            if (strpos($this->config->get($classname . '_mid'), "_") !== false) {
                $mids = explode(",", $this->config->get($classname . '_mid'));
                foreach ($mids as $mid) {
                    $mid = trim($mid);
                    $tmp = explode("_", $mid); // Explode the mid from currency
                    if (strtoupper($tmp[1]) == strtoupper($currency)) {
                        $found_mid = $tmp[0];
                        break;
                    } else {
                        $found_mid = false;
                    }
                }
                if (!$found_mid) { exit ('No mid found for currently selected currency'); }
            } else {
                $found_mid = $this->config->get($classname . '_mid');
            }

            // Loop through KEY and currencies
            if (strpos($this->config->get($classname . '_key'), "_") !== false) {
                $keys = explode(",", $this->config->get($classname . '_key'));
                foreach ($keys as $key) {
                    $key = trim($key);
                    $tmp = explode("_", $key); // Explode the mid from currency
                    if (strtoupper($tmp[1]) == strtoupper($currency)) {
                        $found_key = $tmp[0];
                        break;
                    } else {
                        $found_key = false;
                    }
                }
                if (!$found_key) { exit ('No key found for currently selected currency'); }
            } else {
                $found_key = $this->config->get($classname . '_key');
            }

            // Loop through SECRET and currencies
            if (strpos($this->config->get($classname . '_secret'), "_") !== false) {
                $secrets = explode(",", $this->config->get($classname . '_secret'));
                foreach ($secrets as $secret) {
                    $secret = trim($secret);
                    $tmp = explode("_", $secret); // Explode the mid from currency
                    if (strtoupper($tmp[1]) == strtoupper($currency)) {
                        $found_secret = $tmp[0];
                        break;
                    } else {
                        $found_secret = false;
                    }
                }
                if (!$found_secret) { exit ('No key found for currently selected currency'); }
            } else {
                $found_secret = $this->config->get($classname . '_secret');
            }

            $this->data['action'] 						= 'https://migs.mastercard.com.au/vpcpay';

            $this->data['fields']['vpc_Version'] 		= '1';
            $this->data['fields']['vpc_Command'] 		= 'pay';
            $this->data['fields']['vpc_MerchTxnRef'] 	= $this->session->data['order_id'] . '_' . time();
            $this->data['fields']['vpc_AccessCode'] 	= $found_key;
            $this->data['fields']['vpc_Merchant'] 		= $found_mid;
            $this->data['fields']['vpc_OrderInfo'] 		= $this->session->data['order_id'];
            $this->data['fields']['vpc_Amount'] 		= str_replace(array(',00','.00','.0', ',0'), '', (100*$this->currency->format($order_info['total'], $currency, FALSE, FALSE)));
            $this->data['fields']['vpc_Locale'] 		= 'en';
            $this->data['fields']['vpc_ReturnURL'] 		= (HTTPS_SERVER . 'index.php?route=payment/' . $classname . '/callback');

            ksort($this->data['fields']);

            $hash = trim($found_secret);
            foreach ($this->data['fields'] as $field) {
                $hash .= $field;
            }
            $md5hash = md5($hash);

            $this->data['fields']['vpc_SecureHash'] 	= $md5hash;

        } else { // Merchant Hosted

            $this->data['action'] = (((HTTPS_SERVER) ? HTTPS_SERVER : HTTP_SERVER) . 'index.php?route=payment/' . $classname . '/process');

            $this->data['cc_name_val'] 		= (isset($this->session->data['ccname'])) ? $this->session->data['ccname'] : '';
            $this->data['cc_number_val'] 	= (isset($this->session->data['ccnum'])) ? $this->session->data['ccnum'] : '';
            $this->data['cc_month_val'] 	= (isset($this->session->data['ccmon'])) ? $this->session->data['ccmon'] : '';
            $this->data['cc_year_val'] 		= (isset($this->session->data['ccyr'])) ? $this->session->data['ccyr'] : '';
            $this->data['cc_cvv_val'] 		= (isset($this->session->data['cccvv'])) ? $this->session->data['cccvv'] : '';

            unset($this->session->data['ccname']);
            unset($this->session->data['ccnum']);
            unset($this->session->data['ccmon']);
            unset($this->session->data['ccyr']);
            unset($this->session->data['cccvv']);
            unset($this->session->data['ccissue']);
            unset($this->session->data['ccstart']);
            unset($this->session->data['cctype']);

        }

        $this->id       = 'payment';

        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/' . $classname . '.tpl')) {
            $this->template = $this->config->get('config_template') . '/template/payment/' . $classname . '.tpl';
        } else {
            $this->template = 'default/template/payment/' . $classname . '.tpl';
        }

        $this->render();
    }

    public function confirm() {
        $classname = str_replace('vq2-catalog_controller_payment_', '', basename(__FILE__, '.php'));
        if ($this->config->get($classname . '_ajax')) {
            $this->load->model('checkout/order');
            $this->model_checkout_order->confirm($this->session->data['order_id'], $this->config->get('config_order_status_id'));
        }
    }



    /**
     * Merchant Hosted process function
     *
     */
    public function send() {

        # Generic Init
        $classname = str_replace('vq2-catalog_controller_payment_', '', basename(__FILE__, '.php'));
        $store_url = ($this->config->get('config_ssl') ? (is_numeric($this->config->get('config_ssl'))) ? str_replace('http', 'https', $this->config->get('config_url')) : $this->config->get('config_ssl') : $this->config->get('config_url'));
        $this->data['classname'] = $classname;
        $this->data = array_merge($this->data, $this->load->language('payment/' . $classname));


        # Order Info
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);


        # v14x Backwards Compatibility
        if (isset($order_info['currency_code'])) { $order_info['currency'] = $order_info['currency_code']; }
        if (isset($order_info['currency_value'])) { $order_info['value'] = $order_info['currency_value']; }

        $json = array();

        // If there is no order info then fail.
        if (!$order_info) {
            $json['error'] = $this->language->get('error_no_order');
        }

        // Loop through MID and currencies
        if (strpos($this->config->get($classname . '_mid'), "_") !== false) {
            $mids = explode(",", $this->config->get($classname . '_mid'));
            foreach ($mids as $mid) {
                $tmp = explode("_", $mid); // Explode the mid from currency
                if (strtoupper($tmp[1]) == strtoupper($currency)) {
                    $found_mid = $tmp[0];
                    break;
                } else {
                    $found_mid = false;
                }
            }
            if (!$found_mid) { exit ('No mid found for currently selected currency'); }
        } else {
            $found_mid = $this->config->get($classname . '_mid');
        }

        // Loop through KEY and currencies
        if (strpos($this->config->get($classname . '_key'), "_") !== false) {
            $keys = explode(",", $this->config->get($classname . '_key'));
            foreach ($keys as $key) {
                $tmp = explode("_", $key); // Explode the mid from currency
                if (strtoupper($tmp[1]) == strtoupper($currency)) {
                    $found_key = $tmp[0];
                    break;
                } else {
                    $found_key = false;
                }
            }
            if (!$found_key) { exit ('No key found for currently selected currency'); }
        } else {
            $found_key = $this->config->get($classname . '_key');
        }

        if (!isset($json['error'])) {
            $data['vpc_Version'] 			= '1';
            $data['vpc_Command'] 			= 'pay';
            $data['vpc_MerchTxnRef'] 		= $this->session->data['order_id'] . '_' . time();
            $data['vpc_AccessCode'] 		= $found_key;
            $data['vpc_Merchant'] 			= $found_mid;
            $data['vpc_OrderInfo'] 			= $this->session->data['order_id'];
            $data['vpc_Amount'] 			= str_replace(array(',','.'), '', $this->currency->format($order_info['total'], $order_info['currency'], FALSE, FALSE));
            $data['vpc_CardNum'] 			= $this->request->post['ccnum'];
            $data['vpc_CardExp'] 			= (substr($this->request->post['ccyear'], 2).$this->request->post['ccmon']);
            $data['vpc_CardSecurityCode'] 	= $this->request->post['cccvv'];

            $req = '';
            foreach ($data as $k => $v) {
                $req .= '&' . $k . '=' . $v;
            }

            $url = 'https://migs.mastercard.com.au/vpcdps';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Anz eGate Merchant Website');

            $response = curl_exec($ch);
            curl_close ($ch);

            $resp = array();
            parse_str($response, $resp);

            if ($this->config->get($classname . '_debug')) { file_put_contents(DIR_LOGS . $classname . '_debug.txt', "Request: " . print_r($req,1) . "\r\n Response: " . print_r($resp,1) . "\r\n"); }



            // If we get a successful response back...
            if (isset($resp['vpc_TxnResponseCode'])) {
                switch($resp['vpc_TxnResponseCode']) {
                    case '0':
                        // put values in session for success page
                        $this->session->data[$classname . '']['success'] = array();
                        $this->session->data[$classname . '']['success']['Order Info'] = $resp['vpc_OrderInfo'];
                        $this->session->data[$classname . '']['success']['Receipt No'] = $resp['vpc_ReceiptNo'];
                        $this->session->data[$classname . '']['success']['Transaction No'] = $resp['vpc_TransactionNo'];
                        $this->session->data[$classname . '']['success']['Status Message'] = $resp['vpc_Message'];

                        $this->model_checkout_order->confirm($order_info['order_id'], $this->config->get($classname . '_order_status_id'), $order_info['comment']);
                        //$this->redirect((((HTTPS_SERVER) ? HTTPS_SERVER : HTTP_SERVER) . 'index.php?route=checkout/success'));
                        $json['success'] = ($store_url . 'index.php?route=checkout/migs_gateway_success');
                        break;
                    case '7':
                        $json['error'] = $resp['vpc_Message'];
                        break;
                    default:
                        if (isset($resp['vpc_Message'])) {
                            $json['error'] = $resp['vpc_Message'];
                        } else {
                            $json['error'] = $this->language->get('error_invalid');
                        }
                }
            } else {
                if (isset($resp['vpc_Message'])) {
                    $json['error'] = $resp['vpc_Message'];
                } else {
                    $json['error'] = $this->language->get('error_invalid');
                }
            }
        }

        if (isset($json['error'])) {
            $json['error'] .= ('<br/>' . $this->language->get('error_declined_long') . '<br/>' . $resp['vpc_MerchTxnRef']);
            $json['error'] = '<b>'.$json['error'].'</b>';
        }

        $this->response->setOutput(json_encode($json));
    }


    /**
     * Server Hosted callback function
     *
     */
    private function fail($msg = false) {
        $store_url = ($this->config->get('config_ssl') ? (is_numeric($this->config->get('config_ssl'))) ? str_replace('http', 'https', $this->config->get('config_url')) : $this->config->get('config_ssl') : $this->config->get('config_url'));
        if (!$msg) { $msg = (!empty($this->session->data['error']) ? $this->session->data['error'] : 'Unknown Error'); }
        if (method_exists($this->document, 'addBreadcrumb')) { //1.4.x
            $this->redirect((isset($this->session->data['guest'])) ? ($store_url . 'index.php?route=checkout/guest_step_3') : ($store_url . 'index.php?route=checkout/confirm'));
        } else {
            echo '<html><head><script type="text/javascript">';
            echo 'alert("'.($msg).'");';
            echo 'window.location="' . ($store_url  . 'index.php?route=checkout/checkout') . '";';
            echo '</script></head></html>';
        }
        exit;
    }

    public function callback() {
        $classname = str_replace('vq2-catalog_controller_payment_', '', basename(__FILE__, '.php'));
        // Debug
        if ($this->config->get($classname . '_debug')) {
            if (isset($_POST)) {
                $p_msg = "DEBUG POST VARS:\n"; foreach($_POST as $k=>$v) { $p_msg .= $k."=".$v."\n"; }
            }
            if (isset($_GET)) {
                $g_msg = "DEBUG GET VARS:\n"; foreach($_GET as $k=>$v) { $g_msg .= $k."=".$v."\n"; }
            }
            $msg = ($p_msg . "\r\n" . $g_msg);
            mail($this->config->get('config_email'), $classname . '_debug', $msg);
            if (is_writable(getcwd())) { file_put_contents($classname . '_debug.txt', $msg);}
        }//

        $this->data = array_merge($this->data, $this->load->language('payment/' . $classname));
        $this->load->model('checkout/order');

        $order_id = $this->request->get['vpc_OrderInfo'];
        $order_info = $this->model_checkout_order->getOrder($order_id);

        // If there is no order info then fail.
        if (!$order_info) {
            $this->session->data['error'] = $this->language->get('error_no_order');
            $this->fail();
        }

        // If we get a successful response back...
        if (isset($_GET['vpc_TxnResponseCode'])) {
            switch($_GET['vpc_TxnResponseCode']) {
                case '0':
                    // put post values in session for success page
                    $this->session->data[$classname . '']['success'] = array();
                    $this->session->data[$classname . '']['success']['Order Info'] = $this->request->get['vpc_OrderInfo'];
                    $this->session->data[$classname . '']['success']['Receipt No'] = $this->request->get['vpc_ReceiptNo'];
                    $this->session->data[$classname . '']['success']['Transaction No'] = $this->request->get['vpc_TransactionNo'];
                    $this->session->data[$classname . '']['success']['Status Message'] = $this->request->get['vpc_Message'];

                    $this->model_checkout_order->confirm($order_info['order_id'], $this->config->get($classname . '_order_status_id'), $order_info['comment']);
                    $this->redirect((((HTTPS_SERVER) ? HTTPS_SERVER : HTTP_SERVER) . 'index.php?route=checkout/migs_gateway_success'));
                case '7':
                    $this->session->data['error'] = (urldecode($_GET['vpc_Message']) . '<br/>' . $this->language->get('error_declined_long') . '<br/>' . $_GET['vpc_MerchTxnRef']) ;
                    break;
                default:
                    if (isset($_GET['vpc_Message'])) {
                        $this->session->data['error'] = (urldecode($_GET['vpc_Message']) . '<br/>' . $this->language->get('error_declined_long') . '<br/>' . $_GET['vpc_MerchTxnRef']) ;
                    } else {
                        $this->session->data['error'] = $this->language->get('error_invalid');
                    }
            }
        } else {
            if (isset($_GET['vpc_Message'])) {
                $this->session->data['error'] = (urldecode($_GET['vpc_Message']) . '<br/>' . $this->language->get('error_declined_long') . '<br/>' . $_GET['vpc_MerchTxnRef']) ;
            } else {
                $this->session->data['error'] = $this->language->get('error_invalid');
            }
        }
        $this->fail();
    }
}
?>