<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 4/11/2016
 * Time: 11:16 AM
 */
class Transaction extends CI_Controller
{
    function __construct(){
        parent::__construct();

    }

    function index(){

        $d['orders'] = $this->db->from("order")
            ->join('customer' , "order.customer_id = customer.id"  )
            ->select("order.* , customer.firstname , customer.lastname   ")
            ->order_by("order.id","desc")->get()->result();

        $this->load->view("admin/order_list",$d);

    }
    function detail($id){
        $this->load->model('order');
        $this->load->model('Customer','cus');
        $order = $this->order->getByOrderId($id);
        if(is_object($order) ) {
            $d['orders'] = $this->order->getByCustomerId($order->customer_id);
            $d['customer'] = $this->cus->getBy( array('id' => $order->customer_id ) , 1 );
            $d['order'] = $order;
            $this->load->view('admin/order_detail_view',$d);
        }else{
            show_404();
        }
    }

}