<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 2/19/2016
 * Time: 12:28 PM
 */
class Manufacturer_model extends MY_Model
{

    var $table = "manufacturer";
    var $image = "manufacturer_image";
    var $pre = "M";

}