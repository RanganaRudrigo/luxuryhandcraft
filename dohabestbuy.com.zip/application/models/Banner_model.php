<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 12/17/2015
 * Time: 11:07 AM
 */
class Banner_model extends MY_Model
{
    var $table = 'banner' ;
    var $pre = 'BAN' ;

}