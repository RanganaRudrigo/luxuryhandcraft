<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 12/17/2015
 * Time: 11:07 AM
 */
class Blog_model extends MY_Model
{
     var $table = 'blogs' ;
     var $pre = 'BLOG' ;


}