<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 12/8/2015
 * Time: 2:58 PM
 */
class Slider_model extends MY_Model
{
    var $table = 'slider' ;
    var $pre = 'SLI' ;


}