<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 3/25/2016
 * Time: 3:09 PM
 */
class Spotlight_model extends MY_Model
{
    var $table = 'spotlight' ;
    var $pre = 'SPL' ;


}