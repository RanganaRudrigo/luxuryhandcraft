<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 2/19/2016
 * Time: 10:12 AM
 */
class Category_model extends MY_Model
{

    var $table = "category";
    var $image = "category_image";
    var $pre = "CAT";

    function getMenuList($str=""){
        $q = $this->db->select('id , title as text , category_id ')->from($this->table)->where('status',1)->like('title',$str)->get()->result();
        foreach($q as $r ){
            if($r->category_id != 0){
                $this->getRoot($r , $r->category_id );
            }
            $d[] = $r;
        }
        return $d;
    }

    function getRoot(&$r,$id=0){
        $q = $this->db->select('id , title as text , category_id ')->from($this->table)->where('id',$id)->where('status',1)->get()->row();

        if(is_object($q)){
            $r->text = $q->text ." > " .$r->text;
            if($q->category_id != 0 ){
                $this->getRoot($r,$q->category_id);
            }
        }
    }
}