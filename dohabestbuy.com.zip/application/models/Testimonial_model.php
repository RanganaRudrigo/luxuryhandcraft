<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 3/24/2016
 * Time: 1:01 PM
 */
class Testimonial_model extends MY_Model
{
    var $table = 'testimonial' ;
    var $pre = 'TM' ;
}