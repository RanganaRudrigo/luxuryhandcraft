<?php

/**
 * Created by PhpStorm.
 * User: Gowtham
 * Date: 4/8/2016
 * Time: 11:13 AM
 */
class Order extends MY_Model
{

    function create(){
        $this->db->trans_begin();

        $user = $this->session->userdata("front_user") ;
        $this->db->insert("order" ,
            array(
                'cart_details' =>  json_encode($this->cart->contents()) ,
                'customer_id' => $user['id'],
                'customer_detail' => json_encode($this->session->userdata("front_user")) ,
                'total' => $this->cart->total()
            )
        );

        $this->id = $this->db->insert_id();

        foreach($this->cart->contents() as $item ){
            $order_detail[] = array(
                'order_id' => $this->id ,
                'product_id' => $item['id'],
                'qty' => $item['qty'],
                'price' => $item['price']
            );
        }
        $this->db->insert_batch('order_detail',$order_detail);


        if ($this->db->trans_status() === FALSE){
            $this->db->trans_rollback();
            return FALSE ;
        }else{
            $this->db->trans_commit();
            return TRUE ;
        }

    }

    function getByOrderId($id){
        return $this->db->from("order")->where('id',$id)->get()->row();
    }

    function confirm($id){
        $this->db->where('id',$id);
        $this->db->update('order' , array(
            'status' =>  $this->input->get('vpc_TxnResponseCode') ,
            'receipt_no' => $this->input->get('vpc_ReceiptNo'),
            'transaction_no' => $this->input->get('vpc_TransactionNo')
        ) );
    }

    function getByCustomerId($id){
        return $this->db->from("order")->where('customer_id',$id)->order_by('id','desc')->get()->result();
    }
}